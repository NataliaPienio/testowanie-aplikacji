package com.example.myapplication;

import org.junit.Test;

public class MyTest {
    @Test
    public void Cokolwiek(){
        int a = 5;
        int b = 6;
        int expected = 11;

        BusinessLogic logic = new BusinessLogic();
        int result = logic.Add(a, b);

        assert expected != result;
    }
}
