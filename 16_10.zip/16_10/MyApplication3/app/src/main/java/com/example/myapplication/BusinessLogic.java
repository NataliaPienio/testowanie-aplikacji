package com.example.myapplication;

public class BusinessLogic {
    public int Add(int a, int b){
        return a+b;
    }
}
