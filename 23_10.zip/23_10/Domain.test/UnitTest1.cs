using System.Collections.Generic;
using Domain.NewDirectory;
using Xunit;

namespace Domain.test
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            int a = 10;
            int b = 20;
            int expectedResult = 10;

            var result = GreatestCommonDivisor.GCDiterative(a, b);

            Assert.Equal(expectedResult, result);

        }
         [Theory]
         [InlineData(10,20,10)]
         [InlineData(50,25,25)]
         [InlineData(15, 10, 5)]
         public void GCDTests(int a, int b, int expectedResult) { 
            var result = GreatestCommonDivisor.GCDiterative(a, b);

            Assert.Equal(expectedResult, result);
        }
        [Theory]
        [MemberData(nameof(GCDInputData))]
        public void GCDTests2(int a, int b, int expectedResult) {
            var result = GreatestCommonDivisor.GCDiterative(a, b);

            Assert.Equal(expectedResult, result);
        }
        [Theory]
        [MemberData(nameof(GCDInputData))]
        public void GCDRecursive(int a, int b, int expectedResult) {
            var result = GreatestCommonDivisor.GCDiterative(a, b);

            Assert.Equal(expectedResult, result);
        }

        public static IEnumerable<object[]> GCDInputData =>
            new List<object[]>
            {
                new object[] { 10, 20, 10 },
                new object[] { 10, 30, 10 },
                new object[] { 10, 40, 10 },
            };
        


        }
}